package bd;

public  interface DBStatic {
	/*
	public static boolean mysql_pooling = false;
	public static String mysql_host = "localhost:8889";
	public static String mysql_db = "gr1_rahmani";
	public static String mysql_password = "root";
	public static String mysql_username = "root";
	
	*/
	 public static boolean mysql_pooling = false;
	 public static String mysql_host ="132.227.201.129:33306";
	 public static String mysql_db = "gr1_rahmani";
	 public static String mysql_password = "r1";
	 public static String mysql_username = "gr1_rahmani";
	 
	 
	 
	 public static String hostMongo = "li328.lip6.fr";
	 
}
